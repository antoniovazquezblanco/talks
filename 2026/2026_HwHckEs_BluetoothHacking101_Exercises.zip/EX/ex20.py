#!/usr/bin/env python

import asyncio
from rich.console import Console
from rich.table import Table
from rich.live import Live
from rich.prompt import IntPrompt
from bleak import BleakScanner, BleakClient


async def scan_for_device(console: Console, timeout: float):
    console.log("Scanning for devices...")

    table = Table()
    table.add_column("Num", no_wrap=True)
    table.add_column("RSSI", no_wrap=True)
    table.add_column("MAC", no_wrap=True)
    table.add_column("Name")

    devices = dict()

    def _dev_callback(device, advertisement_data):
        if device.address not in devices:
            devices[device.address] = (table.row_count, device, advertisement_data.local_name)
            table.add_row(str(table.row_count), str(advertisement_data.rssi), device.address, advertisement_data.local_name or "")
        else:
            devices[device.address] = (devices[device.address][0], device, advertisement_data.local_name or devices[device.address][2])
            row_idx, _, name = devices[device.address]
            table.columns[1]._cells[row_idx] = str(advertisement_data.rssi)
            table.columns[3]._cells[row_idx] = name or ""

    scanner = BleakScanner(_dev_callback)

    await scanner.start()
    with Live(table, refresh_per_second=1, console=console):
        await asyncio.sleep(timeout)
    await scanner.stop()

    selected_num = IntPrompt().ask('Enter a device number', console=console)
    console.log(f"Selected device: {selected_num}")

    for num, device, _ in devices.values():
        if num == selected_num:
            return device

    return None


async def main():
    console = Console()

    target = await scan_for_device(console, 5)
    if target is None:
        console.log("[red]No device selected![/red]")
        return

    console.log(f"Connecting to {target}...")
    async with BleakClient(target) as client:
        console.log(f"Connected to {target}!")

        #console.log("Pairing...")
        #await client.pair()

        console.log("Discovering services...")
        for service in client.services:
            console.log(f"[Service] {service}")

    console.log("All done!")


if __name__ == "__main__":
    asyncio.run(main())
