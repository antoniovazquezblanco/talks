#!/usr/bin/env python3
"""
Vulnerable BLE GATT server using Bumble.
Accepts all connections without pairing/auth. Command injection via GATT write.
"""

import asyncio
import os
import subprocess
import logging

from bumble.device import Device
from bumble.hci import Address
from bumble.transport import open_transport
from bumble.gatt import Service, Characteristic, CharacteristicValue
from bumble.core import AdvertisingData
from bumble import data_types

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

SERVICE_UUID = 'CAFECAFE-CAFE-CAFE-CAFE-CAFECAFECAFE'
CHAR_UUID = 'DEADBEEF-DEAD-BEEF-DEAD-BEEFDEADBEEF'
DEVICE_NAME = 'PwnMe Router'

# Mutable state
last_output = bytearray(b'Router management, send command')


def on_read(connection):
    logger.info(f'[READ] {bytes(last_output)}')
    return last_output


def on_write(connection, value):
    global last_output
    cmd = value.decode('utf-8', errors='replace').strip()
    logger.info(f'[WRITE] "{cmd}"')

    if cmd == 'help':
        last_output = bytearray(b'CMDS:date,ip,netstat')
    elif any(c in cmd for c in ['date', 'ip', 'netstat']):
        # Deliberately vulnerable to command injection
        try:
            result = subprocess.check_output(
                cmd, shell=True, timeout=5, stderr=subprocess.STDOUT
            )
            last_output = bytearray(result)
        except subprocess.CalledProcessError as e:
            last_output = bytearray(f'Error: {e.output.decode()}'.encode())
        except subprocess.TimeoutExpired:
            last_output = bytearray(b'Error: command timed out')
    else:
        last_output = bytearray(b'Unknown command. Send "help".')

    logger.info(f'[OUT] {bytes(last_output)[:100]}')


async def main():
    transport = os.environ.get('BT_TRANSPORT', 'hci-socket:0')

    logger.info(f'[*] Opening transport: {transport}')
    async with await open_transport(transport) as hci_transport:
        device = Device.with_hci(
            DEVICE_NAME,
            Address('F0:F1:F2:F3:F4:F5'),
            hci_transport.source,
            hci_transport.sink,
        )
        device.advertising_data = bytes(
            AdvertisingData([data_types.CompleteLocalName(DEVICE_NAME)])
        )

        # Register GATT service
        char_value = CharacteristicValue(read=on_read, write=on_write)
        service = Service(
            SERVICE_UUID,
            [
                Characteristic(
                    uuid=CHAR_UUID,
                    properties=(
                        Characteristic.Properties.READ
                        | Characteristic.Properties.WRITE
                        | Characteristic.Properties.INDICATE
                    ),
                    permissions=(
                        Characteristic.READABLE
                        | Characteristic.WRITEABLE
                    ),
                    value=char_value,
                )
            ],
        )
        device.add_services([service])

        await device.power_on()

        # Start advertising — auto_restart re-advertises after disconnect
        await device.start_advertising(auto_restart=True)

        logger.info(f'[*] Advertising as "{DEVICE_NAME}"')
        logger.info(f'[*] Service UUID: {SERVICE_UUID}')
        logger.info(f'[*] Char UUID:    {CHAR_UUID}')
        logger.info('[*] Waiting for connections...')

        # Run until transport closes
        await hci_transport.source.terminated


if __name__ == '__main__':
    asyncio.run(main())
