#!/bin/bash
# Run with: sudo ./setup_agent.sh
# Runs the vulnerable BLE server using bumble (direct HCI, no bluetoothd).

set -e

ADAPTER="${1:-hci0}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[*] Stopping bluetoothd (bumble uses HCI directly)..."
systemctl stop bluetooth 2>/dev/null || true
sleep 1

echo "[*] Bringing adapter $ADAPTER down (bumble manages it directly)..."
hciconfig "$ADAPTER" down

echo "[*] Installing bumble (if needed)..."
pip install bumble 2>/dev/null || pip3 install bumble 2>/dev/null

echo ""
echo "[*] Starting PwnMe Router BLE server..."
echo "[*] Press Ctrl+C to stop."
echo ""

# hci-socket uses the kernel HCI interface (no need for raw USB access)
export BT_TRANSPORT="hci-socket:${ADAPTER#hci}"
cd "$SCRIPT_DIR"
python3 main_bumble.py
