#!/usr/bin/env python

import usbbluetooth
from scapy_usbbluetooth import UsbBluetoothSocket
from scapy_socketlogger import SocketLogger
from scapy.all import *


def get_controller():
    devices = usbbluetooth.list_controllers()
    return devices[1]


def initialize(socket):
    # Reset
    pkt = HCI_Hdr() / HCI_Command_Hdr() / HCI_Cmd_Reset()
    response = socket.sr1(pkt, verbose=0)
    if response[HCI_Event_Command_Complete].status != 0:
        print("Failed to reset the controller")

    pkt = (
        HCI_Hdr() / HCI_Command_Hdr() / HCI_Cmd_Set_Event_Mask()
    )  # (mask=b"\xff\xff\xff\xff\xff\xff\xff\xff")
    response = socket.sr1(pkt, verbose=0)
    if response[HCI_Event_Command_Complete].status != 0:
        print("Failed to set event mask")
        response.show()


# Socket
controller = get_controller()
socket = UsbBluetoothSocket(controller)

# PCAP Logger
pcap_writer = PcapWriter("ex14.pcap")
logger = SocketLogger(socket, pcap_writer)

print("Initializing...")
initialize(socket)

print("Setting adv params...")
pkt = HCI_Hdr() / HCI_Command_Hdr() / HCI_Cmd_LE_Set_Advertising_Parameters()
response = socket.sr1(pkt, verbose=0)
if response[HCI_Event_Command_Complete].status != 0:
    print("Failed to set adv params")
    response.show()

print("Setting adv data...")
pkt = (
    HCI_Hdr()
    / HCI_Command_Hdr()
    / HCI_Cmd_LE_Set_Advertising_Data(
        data=[
            EIR_Hdr()
            / EIR_Manufacturer_Specific_Data(company_id=0x0006)
            / EIR_Raw(data=b"\x03\x00\x80\x41\x41\x41\x41\x41\x00")
        ]
    )
)
response = socket.sr1(pkt, verbose=0)
if response[HCI_Event_Command_Complete].status != 0:
    print("Failed to set adv data")
    response.show()

print("Enabling advertising...")
pkt = HCI_Hdr() / HCI_Command_Hdr() / HCI_Cmd_LE_Set_Advertise_Enable(enable=1)
response = socket.sr1(pkt, verbose=0)
if response[HCI_Event_Command_Complete].status != 0:
    print("Failed to enable advertising")
    response.show()

import time

time.sleep(10)

print("Done!")

# Cleanup
controller.close()
logger.close()
