#!/usr/bin/env python

import usbbluetooth


def get_controller():
    devices = usbbluetooth.list_controllers()
    return devices[1]


c = get_controller()
print(c)
