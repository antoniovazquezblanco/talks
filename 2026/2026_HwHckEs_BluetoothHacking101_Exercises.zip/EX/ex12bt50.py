#!/usr/bin/env python

import struct
import time
import usbbluetooth
from scapy_usbbluetooth import UsbBluetoothSocket
from scapy_socketlogger import SocketLogger
from scapy.all import *


# Extended advertising HCI commands (BT 5.0+)

class HCI_Cmd_LE_Set_Extended_Advertising_Parameters(Packet):
    name = "HCI_LE_Set_Extended_Advertising_Parameters"
    fields_desc = [
        ByteField("handle", 0),
        LEShortField("adv_event_properties", 0x0013),  # connectable, scannable, legacy
        # Primary advertising interval (3 bytes each)
        X3BytesField("interval_min", 0x0000A0),  # 100ms
        X3BytesField("interval_max", 0x0000A0),
        ByteField("channel_map", 0x07),  # all 3 channels
        ByteField("own_addr_type", 1),  # random
        ByteField("peer_addr_type", 0),
        LEMACField("peer_addr", "00:00:00:00:00:00"),
        ByteField("filter_policy", 0),
        ByteField("tx_power", 0x7F),  # host has no preference
        ByteField("primary_adv_phy", 1),  # 1M
        ByteField("secondary_adv_max_skip", 0),
        ByteField("secondary_adv_phy", 1),  # 1M
        ByteField("sid", 0),
        ByteField("scan_req_notif_enable", 0),
    ]


bind_layers(HCI_Command_Hdr, HCI_Cmd_LE_Set_Extended_Advertising_Parameters, ogf=0x08, ocf=0x0036)


class HCI_Cmd_LE_Set_Advertising_Set_Random_Address(Packet):
    name = "HCI_LE_Set_Advertising_Set_Random_Address"
    fields_desc = [ByteField("handle", 0), LEMACField("addr", None)]


bind_layers(HCI_Command_Hdr, HCI_Cmd_LE_Set_Advertising_Set_Random_Address, ogf=0x08, ocf=0x0035)


class HCI_Cmd_LE_Set_Extended_Advertising_Data(Packet):
    name = "HCI_LE_Set_Extended_Advertising_Data"
    fields_desc = [
        ByteField("handle", 0),
        ByteField("operation", 3),  # complete
        ByteField("fragment_preference", 1),  # no fragmentation
        FieldLenField("len", None, length_of="data", fmt="B"),
        PacketListField("data", [], EIR_Hdr, length_from=lambda pkt: pkt.len),
    ]


bind_layers(HCI_Command_Hdr, HCI_Cmd_LE_Set_Extended_Advertising_Data, ogf=0x08, ocf=0x0037)


class HCI_Cmd_LE_Set_Extended_Advertising_Enable(Packet):
    name = "HCI_LE_Set_Extended_Advertising_Enable"
    fields_desc = [
        ByteField("enable", 1),
        ByteField("num_sets", 1),
        ByteField("handle", 0),
        LEShortField("duration", 0),  # no duration limit
        ByteField("max_events", 0),  # no max
    ]


bind_layers(HCI_Command_Hdr, HCI_Cmd_LE_Set_Extended_Advertising_Enable, ogf=0x08, ocf=0x0039)


def get_controller():
    devices = usbbluetooth.list_controllers()
    return devices[1]


def send_cmd(socket, pkt, description):
    response = socket.sr1(pkt, verbose=0)
    if response[HCI_Event_Command_Complete].status != 0:
        print(f"Failed: {description}")
        response.show()
    else:
        print(f"OK: {description}")
    return response


# Socket
controller = get_controller()
print(controller)
socket = UsbBluetoothSocket(controller)

# PCAP Logger
pcap_writer = PcapWriter("ex12_2.pcap")
logger = SocketLogger(socket, pcap_writer)

# Reset
print("Initializing...")
send_cmd(socket, HCI_Hdr() / HCI_Command_Hdr() / HCI_Cmd_Reset(), "Reset")
send_cmd(socket, HCI_Hdr() / HCI_Command_Hdr() / HCI_Cmd_Set_Event_Mask(), "Set Event Mask")

# Set extended advertising parameters (creates the advertising set)
print("Setting extended adv params...")
pkt = (
    HCI_Hdr()
    / HCI_Command_Hdr()
    / HCI_Cmd_LE_Set_Extended_Advertising_Parameters()
)
send_cmd(socket, pkt, "Set Extended Advertising Parameters")

# Set random address for advertising set 0
print("Setting random address...")
pkt = (
    HCI_Hdr()
    / HCI_Command_Hdr()
    / HCI_Cmd_LE_Set_Advertising_Set_Random_Address(handle=0, addr="AA:BB:CC:DD:EE:02")
)
send_cmd(socket, pkt, "Set Advertising Set Random Address")

# Set extended advertising data
print("Setting extended adv data...")
pkt = (
    HCI_Hdr()
    / HCI_Command_Hdr()
    / HCI_Cmd_LE_Set_Extended_Advertising_Data(
        data=[EIR_Hdr() / EIR_CompleteLocalName(local_name=b"Anton")]
    )
)
send_cmd(socket, pkt, "Set Extended Advertising Data")

# Enable extended advertising
print("Enabling extended advertising...")
pkt = (
    HCI_Hdr()
    / HCI_Command_Hdr()
    / HCI_Cmd_LE_Set_Extended_Advertising_Enable(enable=1)
)
send_cmd(socket, pkt, "Enable Extended Advertising")

time.sleep(10)

print("Done!")

# Cleanup
controller.close()
logger.close()
