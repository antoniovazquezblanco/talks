#!/usr/bin/env python

import usbbluetooth
from scapy_usbbluetooth import UsbBluetoothSocket
from scapy_socketlogger import SocketLogger
from scapy.all import *


def get_controller():
    devices = usbbluetooth.list_controllers()
    return devices[1]


def initialize(socket):
    # Reset
    pkt = HCI_Hdr() / HCI_Command_Hdr() / HCI_Cmd_Reset()
    response = socket.sr1(pkt, verbose=0)
    if response[HCI_Event_Command_Complete].status != 0:
        print("Failed to reset the controller")

    pkt = (
        HCI_Hdr() / HCI_Command_Hdr() / HCI_Cmd_Set_Event_Mask()
    )  # (mask=b"\xff\xff\xff\xff\xff\xff\xff\xff")
    response = socket.sr1(pkt, verbose=0)
    if response[HCI_Event_Command_Complete].status != 0:
        print("Failed to set event mask")
        response.show()


# Socket
controller = get_controller()
socket = UsbBluetoothSocket(controller)

# PCAP Logger
pcap_writer = PcapWriter("ex10.pcap")
logger = SocketLogger(socket, pcap_writer)

print("Initializing...")
initialize(socket)

print("Enabling LE Scan...")
pkt = (
    HCI_Hdr() / HCI_Command_Hdr() / HCI_Cmd_LE_Set_Scan_Enable(enable=1, filter_dups=0)
)
response = socket.sr1(pkt, verbose=0)
if response[HCI_Event_Command_Complete].status != 0:
    print("Failed to enable LE scan")
    response.show()

print("Showing incoming LE Advertising Reports...")
while True:
    pkt = socket.recv()
    if pkt is not None:
        pkt.show()

print("Done!")

# Cleanup
controller.close()
logger.close()
