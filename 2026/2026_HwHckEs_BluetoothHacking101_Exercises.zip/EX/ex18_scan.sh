#!/bin/sh
# Scan for Bluetooth devices using bluetoothctl

echo "Scanning for Bluetooth devices (10 seconds)..."
bluetoothctl --timeout 10 scan on 2>/dev/null &
sleep 10

echo ""
echo "Discovered devices:"
bluetoothctl devices
