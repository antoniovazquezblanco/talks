#!/usr/bin/env python

import time
import asyncio
from rich.console import Console
from rich.table import Table
from rich.live import Live
from rich.prompt import IntPrompt
from bleak import BleakScanner, BleakClient


async def scan_for_device(console: Console):
    console.log("Scanning for devices...")

    devices = dict()
    TIMEOUT = 5  # seconds

    def _dev_callback(device, advertisement_data):
        name = advertisement_data.local_name
        if device.address in devices:
            name = name or devices[device.address]["name"]
        devices[device.address] = {
            "device": device,
            "rssi": advertisement_data.rssi,
            "name": name,
            "last_seen": time.time(),
        }

    def _build_table():
        now = time.time()
        expired = [addr for addr, d in devices.items() if now - d["last_seen"] > TIMEOUT]
        for addr in expired:
            del devices[addr]

        t = Table()
        t.add_column("Num", no_wrap=True)
        t.add_column("RSSI", no_wrap=True)
        t.add_column("MAC", no_wrap=True)
        t.add_column("Name")
        for i, (addr, d) in enumerate(sorted(devices.items(), key=lambda x: x[1]["rssi"], reverse=True)):
            t.add_row(str(i), str(d["rssi"]), addr, d["name"] or "")
        return t

    scanner = BleakScanner(_dev_callback)

    await scanner.start()
    with Live(_build_table(), refresh_per_second=1, console=console) as live:
        while True:
            await asyncio.sleep(1)
            live.update(_build_table())
    await scanner.stop()


async def main():
    console = Console()
    await scan_for_device(console)


if __name__ == "__main__":
    asyncio.run(main())
