#!/usr/bin/env python

import usbbluetooth


devices = usbbluetooth.list_controllers()
for dev in devices:
    print(dev)
