#!/bin/sh
# Perform a "Just Works" BLE pairing with a given MAC address

if [ -z "$1" ]; then
    echo "Usage: $0 <MAC_ADDRESS>"
    exit 1
fi

MAC="$1"

# Set the default agent (NoInputNoOutput = Just Works)
bluetoothctl agent NoInputNoOutput
bluetoothctl default-agent

echo "Pairing with $MAC..."
bluetoothctl pair "$MAC"

echo "Trusting $MAC..."
bluetoothctl trust "$MAC"

echo "Done."
