#!/usr/bin/env python

import usbbluetooth
from scapy_usbbluetooth import UsbBluetoothSocket
from scapy_socketlogger import SocketLogger
from scapy.all import *


def get_controller():
    devices = usbbluetooth.list_controllers()
    return devices[1]

# Socket
controller = get_controller()
socket = UsbBluetoothSocket(controller)

# PCAP Logger
pcap_writer = PcapWriter("ex08.pcap")
logger = SocketLogger(socket, pcap_writer)

# Reset
pkt = HCI_Hdr() / HCI_Command_Hdr() / HCI_Cmd_Reset()
response = socket.sr1(pkt)
response.show()

# Cleanup
controller.close()
logger.close()
