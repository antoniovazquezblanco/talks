#!/usr/bin/env python

import usbbluetooth


def get_controller():
    devices = usbbluetooth.list_controllers()
    return devices[1]


c = get_controller()
print("Opening controller...")
c.open()
print("Sending a reset...")
c.write(b"\x01\x03\x0c\x00")
print("Reading response...")
print(c.read())
c.close()
