#!/usr/bin/env python

import usbbluetooth
from scapy_usbbluetooth import UsbBluetoothSocket
from scapy.all import *


def get_controller():
    devices = usbbluetooth.list_controllers()
    return devices[1]


# Socket
controller = get_controller()
socket = UsbBluetoothSocket(controller)

# Reset
print("Creating a reset packet...")
pkt = HCI_Hdr() / HCI_Command_Hdr() / HCI_Cmd_Reset()
pkt.show()

print("\nSending reset packet and awaiting response...")
response = socket.sr1(pkt)

print("\nShowing response...")
response.show()

# Cleanup
controller.close()
